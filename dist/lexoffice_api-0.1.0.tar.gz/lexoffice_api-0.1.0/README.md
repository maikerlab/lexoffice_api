# Lexoffice Public API
This is a Python Library for interacting with the official public API of lexoffice.